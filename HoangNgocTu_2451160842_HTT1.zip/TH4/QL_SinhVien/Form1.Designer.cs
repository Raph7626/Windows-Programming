namespace QL_SinhVien
{
    partial class Form1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblTitle    = new System.Windows.Forms.Label();
            this.lblMaSV     = new System.Windows.Forms.Label();
            this.lblHoSV     = new System.Windows.Forms.Label();
            this.lblTenSV    = new System.Windows.Forms.Label();
            this.lblNgaySinh = new System.Windows.Forms.Label();
            this.lblGioiTinh = new System.Windows.Forms.Label();
            this.lblMaKhoa   = new System.Windows.Forms.Label();
            this.lblLocKhoa  = new System.Windows.Forms.Label();
            this.lblLocGT    = new System.Windows.Forms.Label();
            this.tbMaSV      = new System.Windows.Forms.TextBox();
            this.tbHoSV      = new System.Windows.Forms.TextBox();
            this.tbTenSV     = new System.Windows.Forms.TextBox();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.rbNam       = new System.Windows.Forms.RadioButton();
            this.rbNu        = new System.Windows.Forms.RadioButton();
            this.cbMaKhoa    = new System.Windows.Forms.ComboBox();
            this.cbLocKhoa   = new System.Windows.Forms.ComboBox();
            this.cbLocGT     = new System.Windows.Forms.ComboBox();
            this.dgSinhVien  = new System.Windows.Forms.DataGridView();
            this.btThem      = new System.Windows.Forms.Button();
            this.btSua       = new System.Windows.Forms.Button();
            this.btXoa       = new System.Windows.Forms.Button();
            this.btLoc       = new System.Windows.Forms.Button();
            this.btThoat     = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgSinhVien)).BeginInit();
            this.SuspendLayout();

            // lblTitle
            this.lblTitle.Text = "Chương Trình Quản Lý Sinh Viên";
            this.lblTitle.Font = new System.Drawing.Font("Times New Roman", 18F, System.Drawing.FontStyle.Bold);
            this.lblTitle.AutoSize = false;
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTitle.Location = new System.Drawing.Point(0, 10);
            this.lblTitle.Size = new System.Drawing.Size(780, 42);
            this.lblTitle.TabIndex = 0;

            // lblMaSV
            this.lblMaSV.Text = "Mã Sinh viên";
            this.lblMaSV.Location = new System.Drawing.Point(20, 68);
            this.lblMaSV.AutoSize = true;
            this.lblMaSV.TabIndex = 1;

            // tbMaSV
            this.tbMaSV.Location = new System.Drawing.Point(118, 65);
            this.tbMaSV.Size = new System.Drawing.Size(130, 22);
            this.tbMaSV.TabIndex = 2;

            // lblHoSV
            this.lblHoSV.Text = "Họ Sinh viên";
            this.lblHoSV.Location = new System.Drawing.Point(260, 68);
            this.lblHoSV.AutoSize = true;
            this.lblHoSV.TabIndex = 3;

            // tbHoSV
            this.tbHoSV.Location = new System.Drawing.Point(355, 65);
            this.tbHoSV.Size = new System.Drawing.Size(130, 22);
            this.tbHoSV.TabIndex = 4;

            // lblTenSV
            this.lblTenSV.Text = "Tên Sinh viên";
            this.lblTenSV.Location = new System.Drawing.Point(500, 68);
            this.lblTenSV.AutoSize = true;
            this.lblTenSV.TabIndex = 5;

            // tbTenSV
            this.tbTenSV.Location = new System.Drawing.Point(595, 65);
            this.tbTenSV.Size = new System.Drawing.Size(130, 22);
            this.tbTenSV.TabIndex = 6;

            // lblNgaySinh
            this.lblNgaySinh.Text = "Ngày sinh";
            this.lblNgaySinh.Location = new System.Drawing.Point(20, 110);
            this.lblNgaySinh.AutoSize = true;
            this.lblNgaySinh.TabIndex = 7;

            // dtpNgaySinh
            this.dtpNgaySinh.Location = new System.Drawing.Point(103, 107);
            this.dtpNgaySinh.Size = new System.Drawing.Size(170, 22);
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtpNgaySinh.TabIndex = 8;

            // lblGioiTinh
            this.lblGioiTinh.Text = "Giới tính";
            this.lblGioiTinh.Location = new System.Drawing.Point(310, 110);
            this.lblGioiTinh.AutoSize = true;
            this.lblGioiTinh.TabIndex = 9;

            // rbNam
            this.rbNam.Text = "Nam";
            this.rbNam.Location = new System.Drawing.Point(380, 109);
            this.rbNam.Size = new System.Drawing.Size(55, 20);
            this.rbNam.Checked = true;
            this.rbNam.TabIndex = 10;

            // rbNu
            this.rbNu.Text = "Nữ";
            this.rbNu.Location = new System.Drawing.Point(440, 109);
            this.rbNu.Size = new System.Drawing.Size(50, 20);
            this.rbNu.TabIndex = 11;

            // lblMaKhoa
            this.lblMaKhoa.Text = "Mã Khoa";
            this.lblMaKhoa.Location = new System.Drawing.Point(510, 110);
            this.lblMaKhoa.AutoSize = true;
            this.lblMaKhoa.TabIndex = 12;

            // cbMaKhoa
            this.cbMaKhoa.Location = new System.Drawing.Point(575, 107);
            this.cbMaKhoa.Size = new System.Drawing.Size(150, 22);
            this.cbMaKhoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbMaKhoa.TabIndex = 13;
            this.cbMaKhoa.Items.AddRange(new object[] { "TOAN", "HOAH", "DIAL", "CNTT", "LY", "HOA" });
            this.cbMaKhoa.SelectedIndex = 0;

            // lblLocKhoa
            this.lblLocKhoa.Text = "Lọc theo Khoa:";
            this.lblLocKhoa.Location = new System.Drawing.Point(20, 148);
            this.lblLocKhoa.AutoSize = true;
            this.lblLocKhoa.TabIndex = 14;

            // cbLocKhoa
            this.cbLocKhoa.Location = new System.Drawing.Point(118, 145);
            this.cbLocKhoa.Size = new System.Drawing.Size(140, 22);
            this.cbLocKhoa.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLocKhoa.TabIndex = 15;
            this.cbLocKhoa.Items.AddRange(new object[] { "-- Tất cả --", "TOAN", "HOAH", "DIAL", "CNTT", "LY", "HOA" });
            this.cbLocKhoa.SelectedIndex = 0;

            // lblLocGT
            this.lblLocGT.Text = "Lọc theo GT:";
            this.lblLocGT.Location = new System.Drawing.Point(280, 148);
            this.lblLocGT.AutoSize = true;
            this.lblLocGT.TabIndex = 16;

            // cbLocGT
            this.cbLocGT.Location = new System.Drawing.Point(370, 145);
            this.cbLocGT.Size = new System.Drawing.Size(110, 22);
            this.cbLocGT.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbLocGT.TabIndex = 17;
            this.cbLocGT.Items.AddRange(new object[] { "-- Tất cả --", "Nam", "Nữ" });
            this.cbLocGT.SelectedIndex = 0;

            // btLoc
            this.btLoc.Text = "Lọc";
            this.btLoc.Location = new System.Drawing.Point(495, 143);
            this.btLoc.Size = new System.Drawing.Size(65, 26);
            this.btLoc.TabIndex = 18;
            this.btLoc.Click += new System.EventHandler(this.btLoc_Click);

            // dgSinhVien
            this.dgSinhVien.Location = new System.Drawing.Point(20, 185);
            this.dgSinhVien.Size = new System.Drawing.Size(740, 275);
            this.dgSinhVien.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) | System.Windows.Forms.AnchorStyles.Left) | System.Windows.Forms.AnchorStyles.Right)));
            this.dgSinhVien.AllowUserToAddRows = false;
            this.dgSinhVien.AllowUserToDeleteRows = false;
            this.dgSinhVien.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgSinhVien.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgSinhVien.MultiSelect = false;
            this.dgSinhVien.ReadOnly = true;
            this.dgSinhVien.RowHeadersVisible = false;
            this.dgSinhVien.TabIndex = 19;
            this.dgSinhVien.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSinhVien_CellClick);

            // btThem
            this.btThem.Text = "Thêm";
            this.btThem.Location = new System.Drawing.Point(140, 475);
            this.btThem.Size = new System.Drawing.Size(75, 28);
            this.btThem.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btThem.TabIndex = 20;
            this.btThem.Click += new System.EventHandler(this.btThem_Click);

            // btSua
            this.btSua.Text = "Sửa";
            this.btSua.Location = new System.Drawing.Point(240, 475);
            this.btSua.Size = new System.Drawing.Size(75, 28);
            this.btSua.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btSua.TabIndex = 21;
            this.btSua.Click += new System.EventHandler(this.btSua_Click);

            // btXoa
            this.btXoa.Text = "Xóa";
            this.btXoa.Location = new System.Drawing.Point(340, 475);
            this.btXoa.Size = new System.Drawing.Size(75, 28);
            this.btXoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.btXoa.TabIndex = 22;
            this.btXoa.Click += new System.EventHandler(this.btXoa_Click);

            // btThoat
            this.btThoat.Text = "Thoát";
            this.btThoat.Location = new System.Drawing.Point(580, 475);
            this.btThoat.Size = new System.Drawing.Size(75, 28);
            this.btThoat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btThoat.TabIndex = 23;
            this.btThoat.Click += new System.EventHandler(this.btThoat_Click);

            // Form1
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(780, 520);
            this.MinimumSize = new System.Drawing.Size(780, 560);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Quản lý sinh viên";
            this.Load += new System.EventHandler(this.Form1_Load);

            this.Controls.AddRange(new System.Windows.Forms.Control[] {
                this.lblTitle,
                this.lblMaSV, this.tbMaSV,
                this.lblHoSV, this.tbHoSV,
                this.lblTenSV, this.tbTenSV,
                this.lblNgaySinh, this.dtpNgaySinh,
                this.lblGioiTinh, this.rbNam, this.rbNu,
                this.lblMaKhoa, this.cbMaKhoa,
                this.lblLocKhoa, this.cbLocKhoa,
                this.lblLocGT, this.cbLocGT, this.btLoc,
                this.dgSinhVien,
                this.btThem, this.btSua, this.btXoa, this.btThoat
            });

            ((System.ComponentModel.ISupportInitialize)(this.dgSinhVien)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        private System.Windows.Forms.Label        lblTitle, lblMaSV, lblHoSV, lblTenSV;
        private System.Windows.Forms.Label        lblNgaySinh, lblGioiTinh, lblMaKhoa, lblLocKhoa, lblLocGT;
        private System.Windows.Forms.TextBox      tbMaSV, tbHoSV, tbTenSV;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.RadioButton  rbNam, rbNu;
        private System.Windows.Forms.ComboBox     cbMaKhoa, cbLocKhoa, cbLocGT;
        private System.Windows.Forms.DataGridView dgSinhVien;
        private System.Windows.Forms.Button       btThem, btSua, btXoa, btLoc, btThoat;
    }
}
