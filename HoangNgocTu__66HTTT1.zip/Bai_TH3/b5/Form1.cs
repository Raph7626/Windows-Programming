﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace b5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_HoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập tên");
                txt_HoTen.Focus();
                return;
            }
            dataGridView1.Rows.Add(
                txt_HoTen.Text, dateTimePicker1.Value.ToString("dd/MM/yyyy"),
                txt_DiaChi.Text, txt_DienThoai.Text);

            txt_HoTen.Clear();
            txt_DienThoai.Clear();
            txt_DiaChi.Clear();
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            if(dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                row.Cells[0].Value = txt_HoTen.Text;
                row.Cells[1].Value = dateTimePicker1.Value.ToString("dd/MM/yyyy");
                row.Cells[2].Value = txt_DiaChi.Text;
                row.Cells[3].Value = txt_DienThoai.Text;
            }
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
                txt_HoTen.Text = row.Cells[0].Value.ToString();
                dateTimePicker1.Text = row.Cells[1].Value.ToString();
                txt_DiaChi.Text = row.Cells[2].Value.ToString();
                txt_DienThoai.Text = row.Cells[3].Value.ToString();
            }
        }
    }
}
