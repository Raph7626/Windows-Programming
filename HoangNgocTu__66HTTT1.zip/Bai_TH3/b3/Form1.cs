﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                rtb_NoiDung.Text = File.ReadAllText(openFileDialog1.FileName);
            }
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                File.WriteAllText(saveFileDialog1.FileName, rtb_NoiDung.Text);
            }

        }

        private void copyToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb_NoiDung.Copy();
        }

        private void cutToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb_NoiDung.Cut();
        }

        private void pasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
            rtb_NoiDung.Paste();
        }

        private void findToolStripMenuItem_Click(object sender, EventArgs e)
        {
            grp_Find_Replace.Visible = true;
            txt_Find.Focus();
        }
        int lastPos = 0;
        private void btn_Find_Click(object sender, EventArgs e)
        {
            string findword = txt_Find.Text;
            int index = rtb_NoiDung.Find(findword, lastPos, RichTextBoxFinds.None);
            if (index >= 0)
            {
                rtb_NoiDung.Select(index, findword.Length);
                rtb_NoiDung.ScrollToCaret();
                rtb_NoiDung.Focus();
                lastPos = index + findword.Length;
            }
            else
            {
                MessageBox.Show("Đã tìm hết văn bản");
                lastPos = 0;
            }
        }

        private void btn_Replace_Click(object sender, EventArgs e)
        {
            if(rtb_NoiDung.SelectedText.Length > 0)
            {
                rtb_NoiDung.SelectedText = txt_Replace.Text;
                btn_Find_Click(sender, e);
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (fontDialog1.ShowDialog() == DialogResult.OK)
            {
                rtb_NoiDung.SelectionFont = fontDialog1.Font;
            }
        }

        private void colorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(colorDialog1.ShowDialog() == DialogResult.OK)
            {
                rtb_NoiDung.SelectionColor = fontDialog1.Color;
            }
        }

        private void toUpperToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(rtb_NoiDung.SelectedText))
            {
                rtb_NoiDung.SelectedText = rtb_NoiDung.SelectedText.ToUpper();
            }
        }

        private void toLowerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(rtb_NoiDung.SelectedText))
            {
                rtb_NoiDung.SelectedText = rtb_NoiDung.SelectedText.ToLower();
            }
        }
    }
}