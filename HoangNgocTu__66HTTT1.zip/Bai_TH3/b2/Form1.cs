﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        double a, b, c;

        private void đổiFontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control control = contextMenuStrip1.SourceControl;
            if (change_Font.ShowDialog() == DialogResult.OK)
            {
                control.Font = change_Font.Font;
            }
        }

        private void đổiMàuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Control control = contextMenuStrip1.SourceControl;
            if (change_Color.ShowDialog() == DialogResult.OK)
            {
                control.ForeColor = change_Color.Color;
            }
        }

        private void btn_Kq_Click(object sender, EventArgs e)
        {
            if(string.IsNullOrEmpty(txt_a.Text) || string.IsNullOrEmpty(txt_b.Text) || string.IsNullOrEmpty(txt_c.Text))
            {
                MessageBox.Show("a và b và c không được để trống");
                return;
            }
            if(!double.TryParse(txt_a.Text, out a))
            {
                MessageBox.Show("a phải là số double");
                return;
            }
            if (!double.TryParse(txt_b.Text, out b))
            {
                MessageBox.Show("b phải là số double");
                return;
            }
            if (!double.TryParse(txt_c.Text, out c))
            {
                MessageBox.Show("c phải là số double");
                return;
            }
            double denta = b*b - 4*a*c;
            if (denta > 0)
            {
                double x1 = (-b + Math.Sqrt(denta)) / (2 * a);
                double x2 = (-b - Math.Sqrt(denta)) / (2 * a);
                lbl_Kq.Text = $"Phương trình có 2 nghiệm phân biệt:\nx1 = {x1}\nx2={x2}";
            }
            else if (denta == 0)
            {
                double x = -b / (2 * a);
                lbl_Kq.Text = $"Phương trình có nghiệm kép:\nx = {x}";
            }
            else
            {
                lbl_Kq.Text = $"Phương trình vô nghiệm";
            }
        }
    }
}
