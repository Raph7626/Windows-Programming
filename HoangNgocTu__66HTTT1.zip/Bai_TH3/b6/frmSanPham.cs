﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b6
{
    public partial class frmSanPham : Form
    {
        public frmSanPham()
        {
            InitializeComponent();
        }
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            DataGridViewRow row = dataGridView1.Rows[e.RowIndex];
            txt_Msp.Text = row.Cells[0].Value.ToString();
            dtpNgaySinh.Text = row.Cells[1].Value.ToString();
            txt_TenSp.Text = row.Cells[2].Value.ToString();
            txt_DonGia.Text = row.Cells[3].Value.ToString();
        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add(
                txt_Msp.Text, dtpNgaySinh.Text, txt_TenSp.Text, txt_DonGia.Text);
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                row.Cells[0].Value = txt_Msp.Text;
                row.Cells[1].Value = dtpNgaySinh.Value.ToString("dd/MM/yyyy");
                row.Cells[2].Value = txt_TenSp.Text;
                row.Cells[3].Value = txt_DonGia.Text;
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                dataGridView1.Rows.Remove(dataGridView1.SelectedRows[0]);

            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
