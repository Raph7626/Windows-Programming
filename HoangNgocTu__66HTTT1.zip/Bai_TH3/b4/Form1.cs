﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b4
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {
            string[] nameOfMonth =
            {
                "Một", "Hai", "Ba", "Tư", "Năm", "Sáu", "Bảy", "Tám",
                "Chín", "Mười", "Mười Một", "Mười Hai"
            };
            int monthIndex = dateTimePicker1.Value.Month - 1;
            string monthText = nameOfMonth[monthIndex];
            dateTimePicker1.CustomFormat = "dd 'Tháng' '" + monthText + "' yyyy";
        }

        private void btn_Them_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(txt_HoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập tên");
                txt_HoTen.Focus();
                return;
            }
            ListViewItem item = new ListViewItem(txt_HoTen.Text);
            item.SubItems.Add(dateTimePicker1.Text);
            item.SubItems.Add(txt_DiaChi.Text);
            item.SubItems.Add(txt_DienThoai.Text);
            listView1.Items.Add(item);
            txt_HoTen.Clear();
            txt_DienThoai.Clear();
            txt_DiaChi.Clear();
        }

        private void btn_Xoa_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                listView1.Items.Remove(listView1.SelectedItems[0]);
            }
        }

        private void btn_Sua_Click(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                item.SubItems[0].Text = txt_HoTen.Text;
                item.SubItems[1].Text = dateTimePicker1.Text;
                item.SubItems[2].Text = txt_DiaChi.Text;
                item.SubItems[3].Text = txt_DienThoai.Text;
            }
        }

        private void btn_Thoat_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listView1.SelectedItems.Count > 0)
            {
                ListViewItem item = listView1.SelectedItems[0];
                txt_HoTen.Text = item.SubItems[0].Text;
                dateTimePicker1.Text = item.SubItems[1].Text;
                txt_DiaChi.Text = item.SubItems[2].Text;
                txt_DienThoai.Text = item.SubItems[3].Text;
            }
        }
    }
}
