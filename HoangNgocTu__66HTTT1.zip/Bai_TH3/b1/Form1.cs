﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace b1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void backColorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (change_BackColor.ShowDialog() == DialogResult.OK)
            {
                this.BackColor = change_BackColor.Color;
            }
        }

        private void backImageToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if(change_BackImage.ShowDialog() == DialogResult.OK)
            {
                this.BackgroundImage = Image.FromFile(change_BackImage.FileName);
            }
        }

        private void fontToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            if(change_Font.ShowDialog() == DialogResult.OK)
            {
                this.Font = change_Font.Font;
                foreach (ToolStripMenuItem item in menuStrip1.Items)
                {
                    item.Font = change_Font.Font;
                }
            }
        }
    }
}
