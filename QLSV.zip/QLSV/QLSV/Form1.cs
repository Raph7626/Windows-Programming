﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace QLSV
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        string chuoiketnoi = "Data Source=21-209B5; Initial Catalog=QLSV; Integrated Security=True";
        SqlConnection conn = null;
        private void Form1_Load(object sender, EventArgs e)
        {
            
            SqlConnection conn = new SqlConnection(chuoiketnoi);
            conn.Open();
            string sql="Select * from Sinhvien";
            SqlDataAdapter daSV = new SqlDataAdapter(sql, conn);
            DataTable dtSV = new DataTable();
            daSV.Fill(dtSV);
            dgvSV.DataSource = dtSV;
              
        }
    }
}
